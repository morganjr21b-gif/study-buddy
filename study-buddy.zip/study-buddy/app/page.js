"use client";

import { useState, useRef, useEffect } from "react";

export default function Home() {
  const [subject, setSubject] = useState("");
  const [started, setStarted] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function sendMessage(text) {
    const newMessages = [...messages, { role: "user", content: text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: newMessages, subject }),
    });
    const data = await res.json();
    setLoading(false);

    if (data.error) {
      setMessages([...newMessages, { role: "assistant", content: "Oops, something went wrong. Try again!" }]);
      return;
    }
    setMessages([...newMessages, { role: "assistant", content: data.reply }]);
  }

  function handleStart() {
    if (!subject.trim()) return;
    setStarted(true);
    sendMessage(`Let's start learning about ${subject}. Please introduce the topic simply.`);
  }

  function handleSend() {
    if (!input.trim() || loading) return;
    sendMessage(input);
  }

  if (!started) {
    return (
      <main style={styles.center}>
        <div style={styles.card}>
          <h1 style={{ marginBottom: 8 }}>📚 Study Buddy</h1>
          <p style={{ color: "#666", marginBottom: 20 }}>What do you want to learn today?</p>
          <input
            style={styles.input}
            placeholder="e.g. photosynthesis, algebra, Spanish verbs"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleStart()}
          />
          <button style={styles.button} onClick={handleStart}>
            Start Learning
          </button>
        </div>
      </main>
    );
  }

  return (
    <main style={styles.chatWrap}>
      <div style={styles.header}>📚 Study Buddy — {subject}</div>
      <div style={styles.messages}>
        {messages.map((m, i) => (
          <div
            key={i}
            style={{
              ...styles.bubble,
              alignSelf: m.role === "user" ? "flex-end" : "flex-start",
              background: m.role === "user" ? "#4f46e5" : "#f1f1f1",
              color: m.role === "user" ? "white" : "black",
            }}
          >
            {m.content}
          </div>
        ))}
        {loading && <div style={{ ...styles.bubble, background: "#f1f1f1" }}>Thinking...</div>}
        <div ref={bottomRef} />
      </div>
      <div style={styles.inputRow}>
        <input
          style={styles.chatInput}
          placeholder="Type your answer or question..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
        />
        <button style={styles.sendButton} onClick={handleSend}>
          Send
        </button>
      </div>
    </main>
  );
}

const styles = {
  center: {
    height: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "#fafafa",
  },
  card: {
    background: "white",
    padding: 32,
    borderRadius: 16,
    boxShadow: "0 2px 12px rgba(0,0,0,0.08)",
    width: 340,
    textAlign: "center",
  },
  input: {
    width: "100%",
    padding: 12,
    borderRadius: 8,
    border: "1px solid #ddd",
    marginBottom: 16,
    boxSizing: "border-box",
    fontSize: 16,
  },
  button: {
    width: "100%",
    padding: 12,
    borderRadius: 8,
    border: "none",
    background: "#4f46e5",
    color: "white",
    fontSize: 16,
    cursor: "pointer",
  },
  chatWrap: {
    display: "flex",
    flexDirection: "column",
    height: "100vh",
    background: "#fafafa",
  },
  header: {
    padding: 16,
    background: "#4f46e5",
    color: "white",
    fontWeight: "bold",
  },
  messages: {
    flex: 1,
    overflowY: "auto",
    padding: 16,
    display: "flex",
    flexDirection: "column",
    gap: 10,
  },
  bubble: {
    maxWidth: "75%",
    padding: "10px 14px",
    borderRadius: 14,
    fontSize: 15,
    lineHeight: 1.4,
    whiteSpace: "pre-wrap",
  },
  inputRow: {
    display: "flex",
    padding: 12,
    background: "white",
    borderTop: "1px solid #eee",
  },
  chatInput: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    border: "1px solid #ddd",
    fontSize: 15,
  },
  sendButton: {
    marginLeft: 8,
    padding: "0 20px",
    borderRadius: 8,
    border: "none",
    background: "#4f46e5",
    color: "white",
    fontSize: 15,
    cursor: "pointer",
  },
};
